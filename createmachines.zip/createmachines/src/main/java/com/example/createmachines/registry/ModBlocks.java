// Path: src/main/java/com/example/createmachines/registry/ModBlocks.java
package com.example.createmachines.registry;

import com.example.createmachines.CreateMachinesMod;
import com.example.createmachines.content.machine.MachineBlock;
import com.example.createmachines.content.machine.Processors;
import com.example.createmachines.content.solar.SolarEngineBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Регистрация всех машин. Каждая перерабатывающая машина = MachineBlock + свой "обработчик" рецептов. */
public final class ModBlocks {

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(CreateMachinesMod.MODID);

    /** Рудодробилка: руда → в 2–3 раза больше сырья. */
    public static final DeferredBlock<MachineBlock> ORE_CRUSHER = BLOCKS.register("ore_crusher",
            () -> new MachineBlock(machine(MapColor.STONE), Processors.ORE_CRUSHING));

    /** Кинетическая плавильня: плавит без топлива; из сырой руды иногда даёт двойной слиток. */
    public static final DeferredBlock<MachineBlock> KINETIC_SMELTER = BLOCKS.register("kinetic_smelter",
            () -> new MachineBlock(machine(MapColor.COLOR_ORANGE).lightLevel(s -> 8), Processors.SMELTING));

    /** Механический уплотнитель: 9 слитков → блок, 4 кварца → блок кварца и т.п. */
    public static final DeferredBlock<MachineBlock> COMPACTOR = BLOCKS.register("compactor",
            () -> new MachineBlock(machine(MapColor.COLOR_YELLOW), Processors.COMPACTING));

    /** Измельчитель: булыжник → гравий → песок, кости → костная мука и т.д. */
    public static final DeferredBlock<MachineBlock> PULVERIZER = BLOCKS.register("pulverizer",
            () -> new MachineBlock(machine(MapColor.STONE), Processors.PULVERIZING));

    /** Солнечный двигатель: днём под открытым небом крутит валы. */
    public static final DeferredBlock<SolarEngineBlock> SOLAR_ENGINE = BLOCKS.register("solar_engine",
            () -> new SolarEngineBlock(machine(MapColor.COLOR_LIGHT_BLUE)));

    /** Общие свойства: как у механизмов Create; noOcclusion — сквозь вырез виден вал. */
    private static BlockBehaviour.Properties machine(MapColor color) {
        return BlockBehaviour.Properties.of()
                .mapColor(color)
                .strength(2.5F, 6.0F)
                .requiresCorrectToolForDrops()
                .sound(SoundType.NETHERITE_BLOCK)
                .noOcclusion();
    }

    private ModBlocks() {}
}
