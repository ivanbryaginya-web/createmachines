// Path: src/main/java/com/example/createmachines/content/machine/Processors.java
package com.example.createmachines.content.machine;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SingleRecipeInput;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Все "рецептные книги" машин аддона. */
public final class Processors {

    // =====================================================================
    //  РУДОДРОБИЛКА: руда → много сырья (обычная кирка дала бы 1 сырьё)
    // =====================================================================

    /** Правило дробления: тег руды → предмет, гарантированное количество, шанс +1 бонусом. */
    private record CrushRule(TagKey<Item> oreTag, ResourceLocation output, int count, float bonusChance) {}

    private static final List<CrushRule> CRUSH_RULES = List.of(
            crush("iron", "minecraft:raw_iron", 2, 0.5F),
            crush("gold", "minecraft:raw_gold", 2, 0.5F),
            crush("copper", "minecraft:raw_copper", 6, 0.5F),
            crush("zinc", "create:raw_zinc", 2, 0.5F),          // руда цинка из Create
            crush("coal", "minecraft:coal", 3, 0.5F),
            crush("redstone", "minecraft:redstone", 8, 0.5F),
            crush("lapis", "minecraft:lapis_lazuli", 10, 0.5F),
            crush("diamond", "minecraft:diamond", 2, 0.25F),
            crush("emerald", "minecraft:emerald", 2, 0.25F),
            crush("quartz", "minecraft:quartz", 3, 0.5F),
            crush("netherite_scrap", "minecraft:netherite_scrap", 2, 0.0F)
    );

    /** Руды ищем по общим тегам c:ores/... — так подхватываются и глубинные, и незерские варианты, и руды других модов. */
    private static CrushRule crush(String ore, String output, int count, float bonus) {
        TagKey<Item> tag = TagKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath("c", "ores/" + ore));
        return new CrushRule(tag, ResourceLocation.parse(output), count, bonus);
    }

    public static final MachineProcessor ORE_CRUSHING = new MachineProcessor() {
        @Override
        public MachineProcessor.Result process(ItemStack input, ServerLevel level, RandomSource random) {
            for (CrushRule rule : CRUSH_RULES) {
                if (!input.is(rule.oreTag())) continue;
                // Если нужного мода нет (например, Create без цинка) — правило пропускается
                Item output = BuiltInRegistries.ITEM.getOptional(rule.output()).orElse(null);
                if (output == null || output == Items.AIR) continue;

                int count = rule.count() + (random.nextFloat() < rule.bonusChance() ? 1 : 0);
                return new MachineProcessor.Result(1, List.of(new ItemStack(output, count)));
            }
            return null;
        }

        @Override
        public SoundEvent sound() {
            return SoundEvents.GRINDSTONE_USE;
        }

        @Override
        public int workPerOperation() {
            return 3840; // руда твёрдая — на 50% дольше обычного
        }
    };

    // =====================================================================
    //  КИНЕТИЧЕСКАЯ ПЛАВИЛЬНЯ: любые рецепты печи, без топлива
    // =====================================================================

    /** Сырая руда (в т.ч. дроблёная руда Create) с шансом 50% даёт двойной слиток. */
    private static final TagKey<Item> RAW_MATERIALS =
            TagKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath("c", "raw_materials"));
    private static final TagKey<Item> CREATE_CRUSHED =
            TagKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath("create", "crushed_raw_materials"));

    public static final MachineProcessor SMELTING = new MachineProcessor() {
        @Override
        public MachineProcessor.Result process(ItemStack input, ServerLevel level, RandomSource random) {
            SingleRecipeInput recipeInput = new SingleRecipeInput(input.copyWithCount(1));
            return level.getRecipeManager().getRecipeFor(RecipeType.SMELTING, recipeInput, level)
                    .map(holder -> {
                        ItemStack result = holder.value().assemble(recipeInput, level.registryAccess());
                        if (result.isEmpty()) return null;
                        boolean ore = input.is(RAW_MATERIALS) || input.is(CREATE_CRUSHED);
                        if (ore && random.nextFloat() < 0.5F) result.grow(result.getCount()); // двойной слиток!
                        return new MachineProcessor.Result(1, List.of(result));
                    })
                    .orElse(null);
        }

        @Override
        public SoundEvent sound() {
            return SoundEvents.BLASTFURNACE_FIRE_CRACKLE;
        }
    };

    // =====================================================================
    //  МЕХАНИЧЕСКИЙ УПЛОТНИТЕЛЬ: 9 одинаковых → блок (или 4 → блок)
    // =====================================================================

    public static final MachineProcessor COMPACTING = new MachineProcessor() {
        @Override
        public MachineProcessor.Result process(ItemStack input, ServerLevel level, RandomSource random) {
            // Сначала пробуем сетку 3x3 (слитки, самородки, алмазы...), затем 2x2 (кварц, снежки, глина...)
            for (int size : new int[]{3, 2}) {
                int needed = size * size;
                if (input.getCount() < needed) continue;

                List<ItemStack> grid = new ArrayList<>(Collections.nCopies(needed, input.copyWithCount(1)));
                CraftingInput craftingInput = CraftingInput.of(size, size, grid);
                ItemStack result = level.getRecipeManager()
                        .getRecipeFor(RecipeType.CRAFTING, craftingInput, level)
                        .map(holder -> holder.value().assemble(craftingInput, level.registryAccess()))
                        .orElse(ItemStack.EMPTY);
                if (!result.isEmpty()) return new MachineProcessor.Result(needed, List.of(result));
            }
            return null;
        }

        @Override
        public SoundEvent sound() {
            return SoundEvents.PISTON_EXTEND;
        }
    };

    // =====================================================================
    //  ИЗМЕЛЬЧИТЕЛЬ: простая таблица "предмет → что получится"
    // =====================================================================

    /** Выход: предмет, количество, а также необязательный "бонус" с шансом. */
    private record Grind(Item output, int count, Item bonus, float bonusChance) {}

    private static final Map<Item, Grind> GRIND_TABLE = new LinkedHashMap<>();

    static {
        GRIND_TABLE.put(Items.STONE, new Grind(Items.COBBLESTONE, 1, Items.AIR, 0));
        GRIND_TABLE.put(Items.COBBLESTONE, new Grind(Items.GRAVEL, 1, Items.AIR, 0));
        GRIND_TABLE.put(Items.COBBLED_DEEPSLATE, new Grind(Items.GRAVEL, 1, Items.AIR, 0));
        GRIND_TABLE.put(Items.GRAVEL, new Grind(Items.SAND, 1, Items.FLINT, 0.15F));
        GRIND_TABLE.put(Items.SANDSTONE, new Grind(Items.SAND, 4, Items.AIR, 0));
        GRIND_TABLE.put(Items.RED_SANDSTONE, new Grind(Items.RED_SAND, 4, Items.AIR, 0));
        GRIND_TABLE.put(Items.NETHERRACK, new Grind(Items.GRAVEL, 1, Items.QUARTZ, 0.05F));
        GRIND_TABLE.put(Items.BONE, new Grind(Items.BONE_MEAL, 5, Items.AIR, 0));
        GRIND_TABLE.put(Items.BLAZE_ROD, new Grind(Items.BLAZE_POWDER, 4, Items.AIR, 0));
        GRIND_TABLE.put(Items.SUGAR_CANE, new Grind(Items.SUGAR, 2, Items.AIR, 0));
        GRIND_TABLE.put(Items.CLAY, new Grind(Items.CLAY_BALL, 4, Items.AIR, 0));
        GRIND_TABLE.put(Items.GLOWSTONE, new Grind(Items.GLOWSTONE_DUST, 4, Items.AIR, 0));
        GRIND_TABLE.put(Items.WHEAT, new Grind(Items.WHEAT_SEEDS, 2, Items.AIR, 0));
    }

    public static final MachineProcessor PULVERIZING = new MachineProcessor() {
        @Override
        public MachineProcessor.Result process(ItemStack input, ServerLevel level, RandomSource random) {
            // Любая шерсть → 4 нити
            if (input.is(ItemTags.WOOL))
                return new MachineProcessor.Result(1, List.of(new ItemStack(Items.STRING, 4)));

            Grind grind = GRIND_TABLE.get(input.getItem());
            if (grind == null) return null;

            List<ItemStack> outputs = new ArrayList<>();
            outputs.add(new ItemStack(grind.output(), grind.count()));
            if (grind.bonus() != Items.AIR && random.nextFloat() < grind.bonusChance())
                outputs.add(new ItemStack(grind.bonus()));
            return new MachineProcessor.Result(1, outputs);
        }

        @Override
        public SoundEvent sound() {
            return SoundEvents.GRAVEL_BREAK;
        }

        @Override
        public int workPerOperation() {
            return 1280; // мягкие материалы — вдвое быстрее
        }
    };

    private Processors() {}
}
