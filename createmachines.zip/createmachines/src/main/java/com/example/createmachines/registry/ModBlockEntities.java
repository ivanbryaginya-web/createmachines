// Path: src/main/java/com/example/createmachines/registry/ModBlockEntities.java
package com.example.createmachines.registry;

import com.example.createmachines.CreateMachinesMod;
import com.example.createmachines.content.machine.MachineBlockEntity;
import com.example.createmachines.content.solar.SolarEngineBlockEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Типы BlockEntity. Все 4 перерабатывающие машины используют один общий тип — логика у них одинаковая. */
public final class ModBlockEntities {

    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITY_TYPES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, CreateMachinesMod.MODID);

    @SuppressWarnings("DataFlowIssue") // build(null): DataFixer модам не нужен
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MachineBlockEntity>> MACHINE =
            BLOCK_ENTITY_TYPES.register("machine", () -> BlockEntityType.Builder.of(MachineBlockEntity::new,
                    ModBlocks.ORE_CRUSHER.get(),
                    ModBlocks.KINETIC_SMELTER.get(),
                    ModBlocks.COMPACTOR.get(),
                    ModBlocks.PULVERIZER.get()).build(null));

    @SuppressWarnings("DataFlowIssue")
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<SolarEngineBlockEntity>> SOLAR_ENGINE =
            BLOCK_ENTITY_TYPES.register("solar_engine", () -> BlockEntityType.Builder
                    .of(SolarEngineBlockEntity::new, ModBlocks.SOLAR_ENGINE.get()).build(null));

    private ModBlockEntities() {}
}
