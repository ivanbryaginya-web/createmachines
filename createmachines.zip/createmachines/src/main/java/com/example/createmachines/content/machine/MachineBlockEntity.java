// Path: src/main/java/com/example/createmachines/content/machine/MachineBlockEntity.java
package com.example.createmachines.content.machine;

import com.example.createmachines.registry.ModBlockEntities;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.Containers;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.ItemHandlerHelper;
import net.neoforged.neoforge.items.ItemStackHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Логика перерабатывающей машины.
 * Каждый тик к "прогрессу" прибавляется текущая скорость вращения (об/мин).
 * Когда прогресс достигает нужного значения — одна операция выполнена.
 * Поэтому чем быстрее крутишь вал, тем быстрее работает машина (как у машин самого Create).
 */
public class MachineBlockEntity extends KineticBlockEntity {

    /**
     * Входной слот на 64 предмета. Снаружи в него можно только КЛАСТЬ:
     * иначе воронка под машиной утащила бы обратно ещё не переработанное сырьё.
     */
    private final ItemStackHandler input = new ItemStackHandler(1) {
        @Override
        protected void onContentsChanged(int slot) {
            setChanged();
            if (level != null && !level.isClientSide) sendData(); // для подсказки очков
        }
    };

    private final IItemHandler insertOnly = new IItemHandler() {
        @Override public int getSlots() { return input.getSlots(); }
        @Override public @NotNull ItemStack getStackInSlot(int slot) { return input.getStackInSlot(slot); }
        @Override public @NotNull ItemStack insertItem(int slot, @NotNull ItemStack stack, boolean simulate) {
            return input.insertItem(slot, stack, simulate);
        }
        @Override public @NotNull ItemStack extractItem(int slot, int amount, boolean simulate) { return ItemStack.EMPTY; }
        @Override public int getSlotLimit(int slot) { return input.getSlotLimit(slot); }
        @Override public boolean isItemValid(int slot, @NotNull ItemStack stack) { return true; }
    };

    private int progress = 0;

    public MachineBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.MACHINE.get(), pos, state);
    }

    public IItemHandler getInputHandler() {
        return insertOnly;
    }

    @Nullable
    private MachineProcessor processor() {
        return getBlockState().getBlock() instanceof MachineBlock machine ? machine.getProcessor() : null;
    }

    @Override
    public void tick() {
        super.tick();
        if (level == null || level.isClientSide) return;

        MachineProcessor processor = processor();
        float speed = Math.abs(getSpeed()); // 0, если вал стоит или сеть перегружена
        if (processor == null || speed == 0) return;

        // Если входной слот пуст — подтягиваем сырьё из инвентаря сверху (сундук, бочка, хранилище Create)
        if (input.getStackInSlot(0).isEmpty() && level.getGameTime() % 10 == 0) pullFromAbove(processor);

        ItemStack stack = input.getStackInSlot(0);
        if (stack.isEmpty()) {
            progress = 0;
            return;
        }

        progress += (int) speed;
        if (progress < processor.workPerOperation()) return;
        progress = 0;

        MachineProcessor.Result result = processor.process(stack.copy(), (ServerLevel) level, level.getRandom());
        if (result == null) {
            // Не получилось. Если не выйдет даже с полной стопкой — машина такое не умеет: выбрасываем,
            // чтобы не застрять. Иначе просто ждём (например, уплотнителю не хватает до 9 штук).
            if (processor.process(stack.copyWithCount(64), (ServerLevel) level, level.getRandom()) == null)
                ejectUnprocessable(stack);
            return;
        }
        if (stack.getCount() < result.inputCount()) return; // уплотнителю не хватает до 9 — ждём

        IItemHandler output = level.getCapability(Capabilities.ItemHandler.BLOCK, worldPosition.below(), Direction.UP);
        if (output != null && !fitsInto(output, result.outputs())) return; // выход забит — ждём

        input.extractItem(0, result.inputCount(), false);
        for (ItemStack out : result.outputs()) deliver(output, out.copy());
        playEffects(processor, stack);
    }

    /** Взять одну стопку подходящего сырья из инвентаря над машиной. */
    private void pullFromAbove(MachineProcessor processor) {
        IItemHandler above = level.getCapability(Capabilities.ItemHandler.BLOCK, worldPosition.above(), Direction.DOWN);
        if (above == null) return;
        for (int slot = 0; slot < above.getSlots(); slot++) {
            ItemStack candidate = above.extractItem(slot, 64, true);
            if (candidate.isEmpty()) continue;
            // Для уплотнителя важно количество, поэтому проверяем на полной стопке
            if (processor.process(candidate.copy(), (ServerLevel) level, level.getRandom()) == null
                    && processor.process(candidate.copyWithCount(64), (ServerLevel) level, level.getRandom()) == null)
                continue;
            ItemStack taken = above.extractItem(slot, 64, false);
            ItemStack rest = input.insertItem(0, taken, false);
            if (!rest.isEmpty()) ItemHandlerHelper.insertItemStacked(above, rest, false);
            return;
        }
    }

    /** Поместятся ли все результаты в инвентарь (пробная вставка без изменений). */
    private static boolean fitsInto(IItemHandler handler, List<ItemStack> stacks) {
        for (ItemStack stack : stacks)
            if (!ItemHandlerHelper.insertItemStacked(handler, stack.copy(), true).isEmpty()) return false;
        return true;
    }

    /** Положить результат в инвентарь снизу или выбросить под машину. */
    private void deliver(@Nullable IItemHandler output, ItemStack stack) {
        if (output != null) stack = ItemHandlerHelper.insertItemStacked(output, stack, false);
        if (!stack.isEmpty()) {
            Containers.dropItemStack(level, worldPosition.getX() + 0.5D, worldPosition.getY() - 0.3D,
                    worldPosition.getZ() + 0.5D, stack);
        }
    }

    /** Предмет, который машина не умеет перерабатывать, выбрасывается наружу. */
    private void ejectUnprocessable(ItemStack stack) {
        ItemStack removed = input.extractItem(0, stack.getCount(), false);
        Containers.dropItemStack(level, worldPosition.getX() + 0.5D, worldPosition.getY() + 1.1D,
                worldPosition.getZ() + 0.5D, removed);
    }

    private void playEffects(MachineProcessor processor, ItemStack processed) {
        ServerLevel server = (ServerLevel) level;
        server.sendParticles(new ItemParticleOption(ParticleTypes.ITEM, processed.copyWithCount(1)),
                worldPosition.getX() + 0.5D, worldPosition.getY() + 1.0D, worldPosition.getZ() + 0.5D,
                8, 0.25D, 0.1D, 0.25D, 0.05D);
        server.playSound(null, worldPosition, processor.sound(), SoundSource.BLOCKS, 0.5F,
                0.9F + level.getRandom().nextFloat() * 0.2F);
    }

    /** Машину сломали — содержимое входного слота выпадает. */
    @Override
    public void destroy() {
        super.destroy();
        if (level != null)
            Containers.dropItemStack(level, worldPosition.getX(), worldPosition.getY(), worldPosition.getZ(),
                    input.getStackInSlot(0));
    }

    /** Строка в подсказке Инженерных очков: что лежит внутри. */
    @Override
    public boolean addToGoggleTooltip(List<Component> tooltip, boolean isPlayerSneaking) {
        super.addToGoggleTooltip(tooltip, isPlayerSneaking);
        ItemStack stack = input.getStackInSlot(0);
        Component content = stack.isEmpty()
                ? Component.translatable("goggles.createmachines.empty").withStyle(ChatFormatting.DARK_GRAY)
                : Component.literal(stack.getCount() + " × ").append(stack.getHoverName()).withStyle(ChatFormatting.GOLD);
        tooltip.add(Component.literal("    ").append(content));
        return true;
    }

    @Override
    protected void write(CompoundTag compound, HolderLookup.Provider registries, boolean clientPacket) {
        super.write(compound, registries, clientPacket);
        compound.put("Input", input.serializeNBT(registries));
        compound.putInt("Progress", progress);
    }

    @Override
    protected void read(CompoundTag compound, HolderLookup.Provider registries, boolean clientPacket) {
        super.read(compound, registries, clientPacket);
        if (compound.contains("Input")) input.deserializeNBT(registries, compound.getCompound("Input"));
        progress = Mth.clamp(compound.getInt("Progress"), 0, Integer.MAX_VALUE);
    }
}
