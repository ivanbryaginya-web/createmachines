// Path: src/main/java/com/example/createmachines/registry/ModStress.java
package com.example.createmachines.registry;

import com.example.createmachines.content.solar.SolarEngineBlockEntity;
import com.simibubi.create.api.stress.BlockStressValues;

/** Нагрузка машин и мощность генератора (в SU на 1 об/мин — Create сам умножает на скорость). */
public final class ModStress {

    public static void register() {
        BlockStressValues.IMPACTS.register(ModBlocks.ORE_CRUSHER.get(), () -> 8.0);     // тяжёлая работа
        BlockStressValues.IMPACTS.register(ModBlocks.KINETIC_SMELTER.get(), () -> 6.0);
        BlockStressValues.IMPACTS.register(ModBlocks.COMPACTOR.get(), () -> 6.0);
        BlockStressValues.IMPACTS.register(ModBlocks.PULVERIZER.get(), () -> 4.0);

        // Солнечный двигатель: 16 SU на 1 об/мин → 512 SU на полной скорости (32 об/мин)
        BlockStressValues.CAPACITIES.register(ModBlocks.SOLAR_ENGINE.get(), () -> 16.0);
        BlockStressValues.RPM.register(ModBlocks.SOLAR_ENGINE.get(),
                new BlockStressValues.GeneratedRpm(SolarEngineBlockEntity.MAX_RPM, true));
    }

    private ModStress() {}
}
