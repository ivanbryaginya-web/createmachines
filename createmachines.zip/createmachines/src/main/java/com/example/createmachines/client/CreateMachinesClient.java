// Path: src/main/java/com/example/createmachines/client/CreateMachinesClient.java
package com.example.createmachines.client;

import com.example.createmachines.CreateMachinesMod;
import com.example.createmachines.registry.ModBlockEntities;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

/** Клиентская часть: вращающийся вал у всех машин. */
@Mod(value = CreateMachinesMod.MODID, dist = Dist.CLIENT)
public class CreateMachinesClient {

    public CreateMachinesClient(IEventBus modEventBus) {
        modEventBus.addListener(CreateMachinesClient::registerRenderers);
    }

    private static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerBlockEntityRenderer(ModBlockEntities.MACHINE.get(), HalfShaftRenderer::new);
        event.registerBlockEntityRenderer(ModBlockEntities.SOLAR_ENGINE.get(), HalfShaftRenderer::new);
    }
}
