// Path: src/main/java/com/example/createmachines/CreateMachinesMod.java
package com.example.createmachines;

import com.example.createmachines.registry.*;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;

/**
 * Аддон "Create: Машины".
 * Рудодробилка, Кинетическая плавильня, Механический уплотнитель, Измельчитель и Солнечный двигатель.
 */
@Mod(CreateMachinesMod.MODID)
public class CreateMachinesMod {

    public static final String MODID = "createmachines";

    public CreateMachinesMod(IEventBus modEventBus, ModContainer modContainer) {
        ModBlocks.BLOCKS.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModBlockEntities.BLOCK_ENTITY_TYPES.register(modEventBus);
        ModCreativeTabs.CREATIVE_TABS.register(modEventBus);

        modEventBus.addListener(CreateMachinesMod::commonSetup);
        modEventBus.addListener(CreateMachinesMod::registerCapabilities);
    }

    /** Сообщаем Create нагрузку машин и мощность генератора. */
    private static void commonSetup(FMLCommonSetupEvent event) {
        ModStress.register();
    }

    /**
     * У машин есть входной слот, видимый снаружи как инвентарь.
     * Поэтому в них можно класть предметы воронкой, конвейером Create, желобом или рукой-манипулятором.
     */
    private static void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ModBlockEntities.MACHINE.get(),
                (machine, side) -> machine.getInputHandler());
    }

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MODID, path);
    }
}
