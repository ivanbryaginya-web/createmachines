// Path: src/main/java/com/example/createmachines/client/HalfShaftRenderer.java
package com.example.createmachines.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import com.simibubi.create.content.kinetics.base.KineticBlockEntityRenderer;
import net.createmod.catnip.render.CachedBuffers;
import net.createmod.catnip.render.SuperByteBuffer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;

/**
 * Рисует вращающийся полувал Create (как у Творческого мотора) на стороне FACING.
 * Стандартный рендерер Create отключается, когда включён Flywheel, и ждёт отдельный "визуал".
 * Мы визуал не регистрируем и рисуем вал всегда — так он виден при любых настройках графики.
 */
public class HalfShaftRenderer<T extends KineticBlockEntity> extends KineticBlockEntityRenderer<T> {

    public HalfShaftRenderer(BlockEntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    protected void renderSafe(T be, float partialTicks, PoseStack ms, MultiBufferSource buffer, int light, int overlay) {
        SuperByteBuffer shaft = CachedBuffers.partialFacing(AllPartialModels.SHAFT_HALF, be.getBlockState());
        // Поворот на угол, синхронный со всей сетью, + подсветка при перегрузке
        renderRotatingBuffer(be, shaft, ms, buffer.getBuffer(RenderType.solid()), light);
    }
}
