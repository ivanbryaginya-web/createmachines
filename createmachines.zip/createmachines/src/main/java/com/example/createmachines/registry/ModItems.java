// Path: src/main/java/com/example/createmachines/registry/ModItems.java
package com.example.createmachines.registry;

import com.example.createmachines.CreateMachinesMod;
import net.minecraft.world.item.BlockItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Предметы-блоки машин. */
public final class ModItems {

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(CreateMachinesMod.MODID);

    public static final DeferredItem<BlockItem> ORE_CRUSHER = ITEMS.registerSimpleBlockItem(ModBlocks.ORE_CRUSHER);
    public static final DeferredItem<BlockItem> KINETIC_SMELTER = ITEMS.registerSimpleBlockItem(ModBlocks.KINETIC_SMELTER);
    public static final DeferredItem<BlockItem> COMPACTOR = ITEMS.registerSimpleBlockItem(ModBlocks.COMPACTOR);
    public static final DeferredItem<BlockItem> PULVERIZER = ITEMS.registerSimpleBlockItem(ModBlocks.PULVERIZER);
    public static final DeferredItem<BlockItem> SOLAR_ENGINE = ITEMS.registerSimpleBlockItem(ModBlocks.SOLAR_ENGINE);

    private ModItems() {}
}
