// Path: src/main/java/com/example/createmachines/registry/ModCreativeTabs.java
package com.example.createmachines.registry;

import com.example.createmachines.CreateMachinesMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Вкладка творческого режима. */
public final class ModCreativeTabs {

    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, CreateMachinesMod.MODID);


    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN = CREATIVE_TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.createmachines"))
                    .icon(() -> ModItems.ORE_CRUSHER.get().getDefaultInstance())
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.ORE_CRUSHER.get());
                        output.accept(ModItems.KINETIC_SMELTER.get());
                        output.accept(ModItems.COMPACTOR.get());
                        output.accept(ModItems.PULVERIZER.get());
                        output.accept(ModItems.SOLAR_ENGINE.get());
                    })
                    .build());

    private ModCreativeTabs() {}
}
