// Path: src/main/java/com/example/createmachines/content/machine/MachineProcessor.java
package com.example.createmachines.content.machine;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** "Рецептная книга" машины: что она умеет делать с предметом. */
public interface MachineProcessor {

    /** Результат одной операции: сколько предметов забрать на входе и что выдать на выходе. */
    record Result(int inputCount, List<ItemStack> outputs) {}

    /**
     * @param input что лежит во входном слоте (копия — менять можно)
     * @return результат или null, если машина не умеет перерабатывать этот предмет
     */
    @Nullable
    Result process(ItemStack input, ServerLevel level, RandomSource random);

    /** Звук при завершении операции. */
    SoundEvent sound();

    /** Сколько "работы" нужно на одну операцию. При 64 об/мин 2560 единиц = 2 секунды. */
    default int workPerOperation() {
        return 2560;
    }
}
