// Path: src/main/java/com/example/createmachines/content/machine/MachineBlock.java
package com.example.createmachines.content.machine;

import com.example.createmachines.content.KineticShapes;
import com.example.createmachines.registry.ModBlockEntities;
import com.simibubi.create.content.kinetics.base.DirectionalKineticBlock;
import com.simibubi.create.foundation.block.IBE;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Перерабатывающая машина. Все 4 машины — этот класс, отличаются только "рецептной книгой" (processor).
 *
 * Как работает:
 *  - вал подключается сбоку (FACING всегда горизонтальный);
 *  - предметы попадают во входной слот (воронка, конвейер, желоб) или берутся из сундука СВЕРХУ;
 *  - результат кладётся в инвентарь СНИЗУ, а если его нет — выпадает под машину.
 */
public class MachineBlock extends DirectionalKineticBlock implements IBE<MachineBlockEntity> {

    private final MachineProcessor processor;

    public MachineBlock(Properties properties, MachineProcessor processor) {
        super(properties);
        this.processor = processor;
    }

    public MachineProcessor getProcessor() {
        return processor;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return KineticShapes.forFacing(state.getValue(FACING));
    }

    /** Вал всегда сбоку: верх и низ машины заняты входом и выходом. */
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        Direction preferred = getPreferredFacing(context);
        if (preferred != null && preferred.getAxis().isHorizontal()
                && (context.getPlayer() == null || !context.getPlayer().isShiftKeyDown()))
            return defaultBlockState().setValue(FACING, preferred);
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    @Override
    public boolean hasShaftTowards(LevelReader level, BlockPos pos, BlockState state, Direction face) {
        return face == state.getValue(FACING);
    }

    @Override
    public Direction.Axis getRotationAxis(BlockState state) {
        return state.getValue(FACING).getAxis();
    }

    @Override
    public Class<MachineBlockEntity> getBlockEntityClass() {
        return MachineBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends MachineBlockEntity> getBlockEntityType() {
        return ModBlockEntities.MACHINE.get();
    }
}
