// Path: src/main/java/com/example/createmachines/content/solar/SolarEngineBlock.java
package com.example.createmachines.content.solar;

import com.example.createmachines.content.KineticShapes;
import com.example.createmachines.registry.ModBlockEntities;
import com.simibubi.create.content.kinetics.base.DirectionalKineticBlock;
import com.simibubi.create.foundation.block.IBE;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Солнечный двигатель: вал сбоку, солнечная панель сверху. Работает днём под открытым небом. */
public class SolarEngineBlock extends DirectionalKineticBlock implements IBE<SolarEngineBlockEntity> {

    public SolarEngineBlock(Properties properties) {
        super(properties);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return KineticShapes.forFacing(state.getValue(FACING));
    }

    /** Вал только сбоку — сверху должна быть панель, смотрящая в небо. */
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        Direction preferred = getPreferredFacing(context);
        if (preferred != null && preferred.getAxis().isHorizontal()
                && (context.getPlayer() == null || !context.getPlayer().isShiftKeyDown()))
            return defaultBlockState().setValue(FACING, preferred);
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    @Override
    public boolean hasShaftTowards(LevelReader level, BlockPos pos, BlockState state, Direction face) {
        return face == state.getValue(FACING);
    }

    @Override
    public Direction.Axis getRotationAxis(BlockState state) {
        return state.getValue(FACING).getAxis();
    }

    @Override
    public boolean hideStressImpact() {
        return true;
    }

    @Override
    public Class<SolarEngineBlockEntity> getBlockEntityClass() {
        return SolarEngineBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends SolarEngineBlockEntity> getBlockEntityType() {
        return ModBlockEntities.SOLAR_ENGINE.get();
    }
}
