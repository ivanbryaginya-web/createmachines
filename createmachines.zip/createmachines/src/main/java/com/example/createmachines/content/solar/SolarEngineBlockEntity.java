// Path: src/main/java/com/example/createmachines/content/solar/SolarEngineBlockEntity.java
package com.example.createmachines.content.solar;

import com.example.createmachines.registry.ModBlockEntities;
import com.simibubi.create.content.kinetics.base.GeneratingKineticBlockEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.state.BlockState;

import java.util.List;

/**
 * Солнечный двигатель.
 * Днём под открытым небом — 32 об/мин, в дождь — 16, ночью или под крышей — стоит.
 * Мощность Create считает сам: 16 SU × скорость (до 512 SU).
 */
public class SolarEngineBlockEntity extends GeneratingKineticBlockEntity {

    public static final int MAX_RPM = 32;
    /** Проверяем солнце раз в 2 секунды — этого достаточно и не нагружает сервер. */
    private static final int CHECK_INTERVAL_TICKS = 40;

    private int currentRpm = 0;

    public SolarEngineBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.SOLAR_ENGINE.get(), pos, state);
    }

    @Override
    public void initialize() {
        super.initialize();
        if (level != null && !level.isClientSide) currentRpm = calculateRpm();
        if (!hasSource() || getGeneratedSpeed() > getTheoreticalSpeed())
            updateGeneratedRotation();
    }

    @Override
    public void tick() {
        super.tick();
        if (level == null || level.isClientSide || level.getGameTime() % CHECK_INTERVAL_TICKS != 0) return;

        int rpm = calculateRpm();
        if (rpm != currentRpm) {
            currentRpm = rpm;
            updateGeneratedRotation(); // Create пересчитает скорость всей сети
        }
    }

    /** Сколько оборотов даёт солнце прямо сейчас. */
    private int calculateRpm() {
        if (!level.dimensionType().hasSkyLight() || !level.canSeeSky(worldPosition.above()) || !level.isDay())
            return 0;
        return level.isRaining() ? MAX_RPM / 2 : MAX_RPM;
    }

    @Override
    public float getGeneratedSpeed() {
        if (!(getBlockState().getBlock() instanceof SolarEngineBlock)) return 0;
        return convertToDirection(currentRpm, getBlockState().getValue(SolarEngineBlock.FACING));
    }

    /** Подсказка очков: светит ли солнце. */
    @Override
    public boolean addToGoggleTooltip(List<Component> tooltip, boolean isPlayerSneaking) {
        super.addToGoggleTooltip(tooltip, isPlayerSneaking);
        tooltip.add(Component.literal("    ").append(currentRpm > 0
                ? Component.translatable("goggles.createmachines.sun_on", currentRpm).withStyle(ChatFormatting.YELLOW)
                : Component.translatable("goggles.createmachines.sun_off").withStyle(ChatFormatting.DARK_GRAY)));
        return true;
    }

    @Override
    protected void write(CompoundTag compound, HolderLookup.Provider registries, boolean clientPacket) {
        super.write(compound, registries, clientPacket);
        compound.putInt("Rpm", currentRpm);
    }

    @Override
    protected void read(CompoundTag compound, HolderLookup.Provider registries, boolean clientPacket) {
        super.read(compound, registries, clientPacket);
        currentRpm = compound.getInt("Rpm");
    }
}
